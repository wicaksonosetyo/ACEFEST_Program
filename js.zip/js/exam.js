const API_BASE = 'https://exam-system-backend.timacefest2025.workers.dev'

class ExamSystem {
    constructor() {
        this.questions = []
        this.userAnswers = {}
        this.startTime = null
        this.duration = 60 * 60 * 1000 // 60 menit
        this.timerInterval = null
        this.lomba = AuthSystem.getLomba()
        this.userData = AuthSystem.getUserData()
    }

    async initialize() {
        if (!AuthSystem.validateAuth()) return

        await this.loadQuestionsFromAPI()
        this.startTimer()
        this.setupEventListeners()
        this.updateUserInfo()
    }

    async loadQuestionsFromAPI() {
        try {
            console.log('Loading questions for lomba:', this.lomba)
            
            const response = await fetch(`${API_BASE}/api/questions?lomba=${this.lomba}`)
            const data = await response.json()

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Gagal memuat soal')
            }

            this.questions = data.questions
            this.renderQuestions()
            this.preloadImages()
            
        } catch (error) {
            console.error('Load questions error:', error)
            this.showError('Gagal memuat soal: ' + error.message)
        }
    }

    renderQuestions() {
        const container = document.getElementById('questions-container')
        container.innerHTML = ''
        
        this.questions.forEach((question, index) => {
            const questionElement = this.createQuestionElement(question, index + 1)
            container.appendChild(questionElement)
        })
        
        this.updateProgress()
    }

    createQuestionElement(question, number) {
        const div = document.createElement('div')
        div.className = 'question-card'
        
        let imageHTML = ''
        if (question.gambar) {
            const imageUrl = `${API_BASE}/api/images/${question.gambar}`
            imageHTML = `
                <div class="question-image">
                    <img src="${imageUrl}" alt="Gambar soal ${number}" 
                         onerror="this.style.display='none'" 
                         loading="lazy">
                    <div class="image-caption">Gambar Soal</div>
                </div>
            `
        }
        
        div.innerHTML = `
            <div class="question-header">
                <h3>Soal ${number}</h3>
            </div>
            <div class="question-text">${question.question_text}</div>
            ${imageHTML}
            <div class="options">
                <label class="option">
                    <input type="radio" name="question_${number}" value="a">
                    <span class="option-label">A.</span>
                    <span class="option-text">${question.option_a}</span>
                </label>
                <label class="option">
                    <input type="radio" name="question_${number}" value="b">
                    <span class="option-label">B.</span>
                    <span class="option-text">${question.option_b}</span>
                </label>
                <label class="option">
                    <input type="radio" name="question_${number}" value="c">
                    <span class="option-label">C.</span>
                    <span class="option-text">${question.option_c}</span>
                </label>
                <label class="option">
                    <input type="radio" name="question_${number}" value="d">
                    <span class="option-label">D.</span>
                    <span class="option-text">${question.option_d}</span>
                </label>
            </div>
        `
        
        const radioButtons = div.querySelectorAll('input[type="radio"]')
        radioButtons.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.setAnswer(number, e.target.value)
            })
        })
        
        return div
    }

    preloadImages() {
        this.questions.forEach((question) => {
            if (question.gambar) {
                const img = new Image()
                img.src = `${API_BASE}/api/images/${question.gambar}`
            }
        })
    }

    calculateScore() {
        let correctCount = 0
        
        this.questions.forEach((question, index) => {
            const questionNumber = index + 1
            const userAnswer = this.userAnswers[questionNumber]
            const correctAnswer = question.correct_answer
            
            if (userAnswer === correctAnswer) {
                correctCount++
            }
        })
        
        const score = correctCount * (question.points || 1.25)
        return {
            score: score,
            correctCount: correctCount,
            totalQuestions: this.questions.length
        }
    }

    async submitExam() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval)
        }

        try {
            const timeSpent = Math.floor((Date.now() - this.startTime) / 1000)
            const scoreResult = this.calculateScore()
            
            const response = await fetch(`${API_BASE}/api/exams/submit`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: this.userData.id,
                    username: this.userData.username,
                    nama: this.userData.nama,
                    sekolah: this.userData.sekolah,
                    lomba: this.userData.lomba,
                    score: scoreResult.score,
                    correct_count: scoreResult.correctCount,
                    total_questions: scoreResult.totalQuestions,
                    answers_detail: this.userAnswers,
                    time_spent: timeSpent
                })
            })

            const result = await response.json()

            if (!response.ok || !result.success) {
                throw new Error(result.error || 'Gagal menyimpan nilai')
            }
            
            this.showResult(scoreResult, result)
            
        } catch (error) {
            console.error('Submit error:', error)
            this.showError('Gagal mengirim jawaban: ' + error.message)
        }
    }

    // Method lainnya tetap sama...
    setAnswer(questionNumber, answer) {
        this.userAnswers[questionNumber] = answer
        this.updateProgress()
        
        const options = document.querySelectorAll(`input[name="question_${questionNumber}"]`)
        options.forEach(option => {
            option.parentElement.classList.remove('selected')
        })
        document.querySelector(`input[name="question_${questionNumber}"][value="${answer}"]`).parentElement.classList.add('selected')
    }

    updateProgress() {
        const answered = Object.keys(this.userAnswers).length
        const total = this.questions.length
        const progress = (answered / total) * 100
        
        const progressBar = document.getElementById('progress-bar')
        const progressText = document.getElementById('progress-text')
        
        if (progressBar) progressBar.style.width = `${progress}%`
        if (progressText) progressText.textContent = `Terjawab: ${answered}/${total}`
    }

    startTimer() {
        this.startTime = Date.now()
        this.updateTimerDisplay()
        
        this.timerInterval = setInterval(() => {
            this.updateTimerDisplay()
            this.checkTimeLimit()
        }, 1000)
    }

    updateTimerDisplay() {
        const elapsed = Date.now() - this.startTime
        const remaining = this.duration - elapsed
        
        if (remaining <= 0) {
            this.submitExam()
            return
        }
        
        const minutes = Math.floor(remaining / 60000)
        const seconds = Math.floor((remaining % 60000) / 1000)
        
        const timerElement = document.getElementById('timer')
        if (timerElement) {
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
        }
    }

    checkTimeLimit() {
        const elapsed = Date.now() - this.startTime
        if (elapsed >= this.duration) {
            this.submitExam()
        }
    }

    showResult(scoreResult, serverResult) {
        const resultHTML = `
            <div class="result-overlay">
                <div class="result-card">
                    <h2>🎉 Ujian Selesai!</h2>
                    <div class="score-display">
                        <div class="final-score">Nilai: ${scoreResult.score.toFixed(2)}</div>
                        <div class="score-details">
                            Jawaban Benar: ${scoreResult.correctCount}/${scoreResult.totalQuestions}
                        </div>
                    </div>
                    <div class="result-actions">
                        <button onclick="window.location.href='results.html'" class="btn-result">
                            Lihat Leaderboard
                        </button>
                        <button onclick="AuthSystem.logout()" class="btn-logout">
                            Logout
                        </button>
                    </div>
                </div>
            </div>
        `
        
        document.body.insertAdjacentHTML('beforeend', resultHTML)
    }

    showError(message) {
        const errorDiv = document.getElementById('error-message') || document.createElement('div')
        errorDiv.id = 'error-message'
        errorDiv.className = 'error-message'
        errorDiv.textContent = message
        errorDiv.style.display = 'block'
        
        if (!document.getElementById('error-message')) {
            document.body.prepend(errorDiv)
        }
    }

    setupEventListeners() {
        const submitBtn = document.getElementById('submit-exam')
        if (submitBtn) {
            submitBtn.addEventListener('click', () => {
                const answered = Object.keys(this.userAnswers).length
                const total = this.questions.length
                
                if (answered < total) {
                    if (!confirm(`Anda baru menjawab ${answered} dari ${total} soal. Yakin ingin submit?`)) {
                        return
                    }
                }
                
                if (confirm('Apakah Anda yakin ingin mengirim jawaban? Setelah dikirim tidak dapat diubah.')) {
                    this.submitExam()
                }
            })
        }
    }

    updateUserInfo() {
        const userInfo = document.getElementById('user-info')
        
        if (userInfo && this.userData) {
            userInfo.innerHTML = `
                <strong>${this.userData.nama}</strong> - ${this.userData.sekolah}<br>
                Lomba: ${this.userData.lomba}
            `
        }
    }
}

// Initialize exam system
const examSystem = new ExamSystem()
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.includes('exam_')) {
        examSystem.initialize()
    }
})
const API_BASE = 'https://exam-system-backend.timacefest2025.workers.dev'

class AuthSystem {
    static async login(username, password) {
        try {
            console.log('Login attempt:', username)
            
            const response = await fetch(`${API_BASE}/api/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            })

            const data = await response.json()
            console.log('Login response:', data)

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'Login failed')
            }
            
            // Store user data
            localStorage.setItem('user_data', JSON.stringify(data.user))
            localStorage.setItem('lomba', data.user.lomba)
            localStorage.setItem('login_time', new Date().toISOString())
            
            // Redirect based on lomba - SUPPORT 5 LOMPA
            if (data.user.lomba.includes('ipa')) {
                window.location.href = './exam_olimpiade_ipa.html';
            } 
            else if (data.user.lomba.includes('math')) {
                window.location.href = './exam_olimpiade_math.html';
            }
            else if (data.user.lomba.includes('ips')) {
                window.location.href = './exam_olimpiade_ips.html';
            }
            else if (data.user.lomba.includes('pai')) {
                window.location.href = './exam_olimpiade_pai.html';
            }
            else if (data.user.lomba.includes('lctp')) {
                window.location.href = './exam_lctp.html';
            }
            else {
                window.location.href = data.redirectUrl || './index.html';
            }
            
        } catch (error) {
            console.error('Login error:', error)
            this.showError(error.message)
        }
    }

    // FUNGSI LAINNYA TETAP SAMA...
    static isAuthenticated() {
        const userData = localStorage.getItem('user_data')
        return !!userData
    }

    static getUserData() {
        const userData = localStorage.getItem('user_data')
        return userData ? JSON.parse(userData) : null
    }

    static getLomba() {
        return localStorage.getItem('lomba')
    }

    static logout() {
        localStorage.removeItem('user_data')
        localStorage.removeItem('lomba')
        localStorage.removeItem('login_time')
        localStorage.removeItem('exam_session')
        window.location.href = './index.html'
    }

    static showError(message) {
        const errorDiv = document.getElementById('error-message')
        if (errorDiv) {
            errorDiv.textContent = message
            errorDiv.style.display = 'block'
            
            setTimeout(() => {
                errorDiv.style.display = 'none'
            }, 5000)
        } else {
            alert('Error: ' + message)
        }
    }

    static validateAuth(requiredLomba = null) {
        if (!this.isAuthenticated()) {
            window.location.href = './index.html'
            return false
        }

        const userData = this.getUserData()
        
        if (requiredLomba) {
            const userLomba = userData.lomba.toLowerCase();
            const requiredLombaLower = requiredLomba.toLowerCase();
            
            if (!userLomba.includes(requiredLombaLower)) {
                this.showError(`Akses ditolak. Hanya peserta ${requiredLomba.toUpperCase()} yang dapat mengakses.`)
                setTimeout(() => {
                    this.logout()
                }, 3000)
                return false
            }
        }

        return true
    }

    static async validateExamAccess() {
    if (!this.isAuthenticated()) {
        return false;
    }

    // Cek apakah sudah pernah submit
    const userData = this.getUserData();
    try {
        const response = await fetch(`${API_BASE}/api/results/ipa`);
        const data = await response.json();
        
        if (data.success && data.leaderboard) {
            const userSubmission = data.leaderboard.find(
                result => result.username === userData.username
            );
            
            if (userSubmission) {
                this.showError('Anda sudah menyelesaikan ujian. Tidak dapat mengulang.');
                setTimeout(() => {
                    window.location.href = './exam_olimpiade_ipa.html';
                }, 3000);
                return false;
            }
        }
    } catch (error) {
        console.error('Error checking submission:', error);
        // Jika error, lanjutkan saja
    }

    return true;
}
}

// Login form handler - TETAP SAMA
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm')
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault()
            
            const username = document.getElementById('username').value.trim()
            const password = document.getElementById('password').value
            
            if (!username || !password) {
                AuthSystem.showError('Harap isi username dan password')
                return
            }
            
            const submitBtn = loginForm.querySelector('button[type="submit"]')
            const originalText = submitBtn.innerHTML
            submitBtn.innerHTML = '<div class="spinner"></div> Memproses...'
            submitBtn.disabled = true
            
            await AuthSystem.login(username, password)
            
            submitBtn.innerHTML = originalText
            submitBtn.disabled = false
        })
    }

    // Auto-redirect untuk 5 lomba
    const userData = AuthSystem.getUserData()
    if (userData && window.location.pathname.includes('index.html')) {
        if (userData.lomba.includes('ipa')) {
            window.location.href = './exam_olimpiade_ipa.html'
        }
        else if (userData.lomba.includes('math')) {
            window.location.href = './exam_olimpiade_math.html'
        }
        else if (userData.lomba.includes('ips')) {
            window.location.href = './exam_olimpiade_ips.html'
        }
        else if (userData.lomba.includes('pai')) {
            window.location.href = './exam_olimpiade_pai.html'
        }
        else if (userData.lomba.includes('lctp')) {
            window.location.href = './exam_lctp.html'
        }
    }
})
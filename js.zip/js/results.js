const API_BASE = 'https://exam-system-backend.timacefest2025.workers.dev'

class ResultsSystem {
    constructor() {
        this.lomba = AuthSystem.getLomba()
        this.userData = AuthSystem.getUserData()
    }

    async initialize() {
        this.displayUserInfo()
        await this.loadLeaderboard()
    }

    displayUserInfo() {
        const userInfo = document.getElementById('user-info')
        if (userInfo && this.userData) {
            userInfo.innerHTML = `
                <strong>${this.userData.nama}</strong> - ${this.userData.sekolah}<br>
                Lomba: ${this.userData.lomba}
            `
        }
    }

    async loadLeaderboard() {
        try {
            // Load leaderboard dari Cloudflare
            const response = await fetch(`${API_BASE}/api/results/${this.lomba}`)
            const data = await response.json()

            if (data.success) {
                this.displayLeaderboard(data.leaderboard)
            } else {
                this.showError('Gagal memuat leaderboard')
            }
        } catch (error) {
            console.error('Load leaderboard error:', error)
            this.showError('Gagal memuat leaderboard')
        }
    }

    displayLeaderboard(leaderboard) {
        const tbody = document.getElementById('leaderboard-body')
        if (!tbody) return

        tbody.innerHTML = ''

        if (leaderboard.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 20px;">
                        Belum ada hasil ujian
                    </td>
                </tr>
            `
            return
        }

        leaderboard.forEach((result, index) => {
            const row = document.createElement('tr')
            
            // Highlight current user
            if (result.username === this.userData?.username) {
                row.className = 'current-user'
            }

            const rank = index + 1
            const timeSpent = this.formatTime(result.time_spent)
            const submittedAt = new Date(result.submitted_at).toLocaleString('id-ID')

            row.innerHTML = `
                <td>${rank}</td>
                <td>${result.nama}</td>
                <td>${result.sekolah}</td>
                <td>${result.score.toFixed(2)}</td>
                <td>${timeSpent}</td>
                <td>${submittedAt}</td>
            `
            tbody.appendChild(row)
        })
    }

    formatTime(seconds) {
        const minutes = Math.floor(seconds / 60)
        const secs = seconds % 60
        return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    }

    showError(message) {
        const errorDiv = document.getElementById('error-message')
        if (errorDiv) {
            errorDiv.textContent = message
            errorDiv.style.display = 'block'
        }
    }
}

// Initialize results system
const resultsSystem = new ResultsSystem()
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.includes('results.html')) {
        resultsSystem.initialize()
    }
})